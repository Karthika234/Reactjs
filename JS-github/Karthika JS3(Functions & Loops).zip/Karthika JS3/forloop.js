
//For loop
for (count =1 ; count<=5; count++)
    {
        console.log("Karthika")
    }
    //Print all the numbers from 1 to 10 
    num = 1
    for (num=1;num<=10;num++)
    {
        console.log(num)
    }
    //Print nos from 1 to 10 ,but increment by 2 in each step using a for loop.
    for (num =1;num<=10;num=num+2)
    {
        console.log(num)
    }
    
    //Print numbers from 1 to 10 in reverse order
    for (num=10;num>=1;num--)
    {
        console.log(num)
    }
    
    //Print only the even numbers from 1 to 10
    for(num=1;num<=10;num++){
        if(num%2 ==0){
            console.log(num)
        }
    }
    //Print 2 tables
    for (i=1;i<=10;i++){
        console.log(i+"*2="+(i*2))
    }
    //While loop
    let count = 1;
    while (count <= 5) {
        console.log(count);
        count++;
    }
    //do while
    let count = 1;
    do {
        console.log(count);
        count++;
    } 
    while (count <= 5);
