//Hello world Program
console.log("Hello world");

//Javascript syntax
// whitespace
let num = true; if (num){console.log("This code doesnt contain any whitespaces");}

//After adding the whitespace
let num=true;
if(num){
    console.log("This is the codde after adding the whitespace");}

//statements
let message="Hello Everyone";
console.log(message);

//JavaScript Variables

var msg;  //declaration
msg="Good Morning"; //Initialization
console.log(msg);

//Constants keywords

const day=365;
day=366; // Uncaught error occurs

//JavaScript datatypes
let counter = 100;
console.log(typeof(counter);//number;

let counter="Hello";
console.log(typeof(counter));//String

let counter=True;
console.log(typeof(counter));//boolean

//JavaScript numbers
let nbs =100;
console.log(num);

let nbs=045;
console.log(num); //Output : 37

//Hexadecimal Numbers
let num=0x1b;
console.log(num);  //OUTPUT : 27

//Floating point number
let amount=3.14e7;
console.log(amount);  //OUTPUT : 31400000

//Boolean type
let error = 'An error occurred';
let hasError = Boolean(error);

console.log(hasError); //OUTPUT : true

//String interpolation
let name="Karthika";
let msg = `Hi , I'm ${name}`;
console.log(msg);

//Length of a string
let ztr ="Karthika Karunanithi";
console .log(ztr.length);

//Object type
let student={
    Name:'Karthika';
    Dept:'IT';
    Status:'3rd year';
}
//Accessing objects
console.log(student.Dept);
console.log(student.Name);
console.log(student.Status);









